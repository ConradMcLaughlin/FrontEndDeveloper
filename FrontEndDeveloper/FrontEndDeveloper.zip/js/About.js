﻿
$(document).ready(function () {
    //alert('Javascript loaded');

    //var divs = $('div');
    //alert(divs.length);

    //$('div').css('background-color', 'Black');

    //$('div').each(function () {
    //    alert($(this).html());
    //});
        
    //You can select multiple items
    //$('div', 'span').css("")
    
    //alert($('#TestDiv').html());

});